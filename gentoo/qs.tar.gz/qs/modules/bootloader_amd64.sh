# $Id$

import bootloader_x86
