# $Id$

import partition_x86

sanity_check_config_partition() {
  warn "Sanity checking partition config for amd64"
}
