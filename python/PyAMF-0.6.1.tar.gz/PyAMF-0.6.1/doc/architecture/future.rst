======================
  Future Development
======================

This is a list of stuff we want to get done before a 1.0
release.


- `Flex Migration <http://dev.pyamf.org/milestone/1.0>`_
- `Python 3.0 compatibility <http://dev.pyamf.org/milestone/0.7>`_
- `Jython support <http://dev.pyamf.org/ticket/269>`_