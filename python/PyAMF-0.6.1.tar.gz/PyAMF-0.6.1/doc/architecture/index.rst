***************
 Architecture
***************

.. toctree::
   :maxdepth: 1

   overview.rst
   typemap.rst
   adapters.rst
   attributecontrol.rst
   classmapping.rst
   future.rst