Maintainers
===========

.. contents::

Note that this is not a full list of PyAMF's authors, however -- for that, you'd
need to look over the log messages to see all the patch contributors.

If you have a question or comment, it's probably best to mail users@pyamf.org,
rather than mailing any of these people directly.

Active
------

   **nick**
      `Nick Joyce <http://dev.pyamf.org/wiki/NickJoyce>`_ <nick at boxdesign.co.uk>
   **thijs**
      `Thijs Triemstra <http://dev.pyamf.org/wiki/ThijsTriemstra>`_ <thijs at collab.com>

Inactive
--------

   **feisley**
      `Jacob Feisley <http://dev.pyamf.org/wiki/JacobFeisley>`_ <feisley at pyamf.org>
   **arnar**
      Arnar Birgisson <arnarbi at gmail.com>
   **mvantellingen**
      Michael van Tellingen <michael.vantellingen at pyamf.org>
   **gerard**
      Gerard Escalante <gerard at pyamf.org>
   **dthompso**
      `Dave Thompson <http://dev.pyamf.org/wiki/DaveThompson>`_ <dave at pyamf.org>
