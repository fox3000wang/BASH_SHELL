= Addressbook Example =

This folder contains an example of the PyAMF SQLAlchemy adapter.

More info can be found in the documentation:
http://pyamf.org/tutorials/actionscript/addressbook.html
