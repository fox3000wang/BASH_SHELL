# Copyright (c) The PyAMF Project.
# See LICENSE.txt for details.

import os.path

images_root = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'images')
