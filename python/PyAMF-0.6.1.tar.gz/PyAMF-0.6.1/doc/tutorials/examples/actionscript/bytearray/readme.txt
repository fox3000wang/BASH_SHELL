ByteArray example
=================

This example shows how to use the ByteArray class
in ActionScript 3.

To run the example, you need to start the server
(in python/server.py) and running on the same domain
where the SWF resides (in the example, localhost) 
and listening on port 8000.

More info can be found in the documentation:
http://pyamf.org/tutorials/actionscript/bytearray.html
