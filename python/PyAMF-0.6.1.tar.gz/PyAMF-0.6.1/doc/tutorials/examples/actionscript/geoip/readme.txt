=============
GeoIP Example
=============

This example uses the open source GeoIP APIs for looking
up the location of an IP address. The API includes support
for lookup of country, region, city, latitude, and longitude.

More info can be found in the documentation:
http://pyamf.org/tutorials/actionscript/geoip.html