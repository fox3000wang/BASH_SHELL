=================
Ohloh API Example
=================

The Ohloh API allows you to pull data from their database,
using a free API key you can get when you register on their
site. This examples retrieves a account based on the user's
email address and shows the profile associated.

More info can be found in the documentation:
http://pyamf.org/tutorials/actionscript/ohloh.html