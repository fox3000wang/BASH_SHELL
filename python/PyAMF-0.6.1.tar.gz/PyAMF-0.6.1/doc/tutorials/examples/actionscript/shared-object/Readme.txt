Local Shared Object Example
===========================

This example loads all your local Shared Object files and
displays their contents.

More info can be found in the documentation:
http://pyamf.org/tutorials/general/sharedobject.html