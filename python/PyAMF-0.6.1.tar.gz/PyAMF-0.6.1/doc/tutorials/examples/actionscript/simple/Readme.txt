= Simple Example =

This folder contains a basic example for PyAMF. 

More info can be found in the documentation:
http://pyamf.org/tutorials/actionscript/simple.html
