=============
UDP example
=============

More info can be found in the documentation:
http://pyamf.org/tutorials/actionscript/udp.html