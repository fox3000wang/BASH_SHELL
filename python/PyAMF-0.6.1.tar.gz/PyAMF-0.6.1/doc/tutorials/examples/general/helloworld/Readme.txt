***************
  Hello World 
***************

This folder contains the Hello World examples
for PyAMF. 

More info can be found in the documentation:
http://pyamf.org/tutorials/general/helloworld/index.html