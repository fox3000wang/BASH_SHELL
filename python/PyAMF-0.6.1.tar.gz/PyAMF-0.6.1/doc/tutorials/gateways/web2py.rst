**********
  web2py 
**********

A nice tutorial for web2py_ can be found on this_ page.


.. _web2py:	http://web2py.com
.. _this:	http://web2py.com/book/default/chapter/09#AMFRPC