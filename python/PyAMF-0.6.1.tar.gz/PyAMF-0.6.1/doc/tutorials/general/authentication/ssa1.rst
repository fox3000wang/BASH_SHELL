****************************
  Adobe Flash Media Server
****************************

.. topic:: Introduction

   This |ActionScript (TM)| 1.0 example can be used with
   Adobe Flash Media Server or Macromedia Flash
   Communication Server MX.

.. contents::


Source
======

- `main.asc <../../examples/general/authentication/flash/ssa1/main.asc>`_


.. |ActionScript (TM)| unicode:: ActionScript U+2122