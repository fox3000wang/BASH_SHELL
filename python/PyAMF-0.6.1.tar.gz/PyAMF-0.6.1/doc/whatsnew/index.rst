.. _whatsnew-index:

#####################
 What's New in PyAMF
#####################

The "What's New in PyAMF" series of essays takes tours through the most
important changes between PyAMF versions.  They are a "must read" for
anyone wishing to stay up-to-date after a new release.

.. toctree::
   :maxdepth: 2

   0.6.rst
   0.5.rst
